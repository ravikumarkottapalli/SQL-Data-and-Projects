select * from studentgrades;
SELECT 
    studentid,
    COUNT(subject) AS Total_subjects,
    SUM(CASE
        WHEN grade = 'A' THEN 1
        ELSE 0
    END) AS TotalGrades_A,
    SUM(CASE
        WHEN grade = 'B' THEN 1
        ELSE 0
    END) AS TotalGrades_B,
    SUM(CASE
        WHEN grade = 'c' THEN 1
        ELSE 0
    END) AS TotalGrades_c,
    SUM(CASE
        WHEN grade = 'A' THEN 3
        WHEN grade = 'B' THEN 2
        WHEN grade = 'c' THEN 1
        ELSE 0
    END) AS Total_points
FROM
    studentgrades
GROUP BY studentid;