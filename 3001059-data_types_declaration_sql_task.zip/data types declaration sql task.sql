CREATE DATABASE ecomdb;

USE ecomdb;

-- Create Publisher Table 
CREATE TABLE Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    product_description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    manufacturer VARCHAR(255),
    manufacture_date DATE,
    weight DECIMAL(5, 2),
    available_stock INT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE
);


-- 2. Extract the first 10 characters of the 'description' column for all products
SELECT LEFT(TRIM(description), 10) AS short_description
FROM Product;

-- 3. Extract the month and year from the manufacture_date column and format them into a single column
SELECT CONCAT(YEAR(manufacture_date), '-', LPAD(MONTH(manufacture_date), 2, '0')) AS formatted_date
FROM Product;

-- 4. Convert the 'order_date' column from a string to a proper date data type for all orders in the 'Orders' table
UPDATE Orders
SET order_date = STR_TO_DATE(order_date, '%Y-%m-%d');

-- 5. Calculate the average salary of employees in the 'Employee' table, rounding the result to the nearest hundred dollars
SELECT ROUND(AVG(salary), -2) AS average_salary
FROM Employee;

