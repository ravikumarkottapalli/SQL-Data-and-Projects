use librarydb;
-- How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?
select distinct book_title, library_branch_branchname, book_copies_no_of_copies from tbl_book tb
left join tbl_book_copies tbc
on tb.book_bookid = tbc.book_copies_bookid
left join tbl_library_branch tlb
on tbc.book_copies_branchid = tlb.library_branch_branchid
where book_title = "The Lost Tribe" and library_branch_branchname = "Sharpstown";

-- How many copies of the book titled "The Lost Tribe" are owned by each library branch?
select distinct book_title, library_branch_branchname, book_copies_no_of_copies  from tbl_book tb
left join tbl_book_copies tbc
on tb.book_bookid = tbc.book_copies_bookid
left join tbl_library_branch tlb on tbc.book_copies_branchid = tlb.library_branch_branchid
where book_title = "The Lost Tribe" ;

-- Retrieve the names of all borrowers who do not have any books checked out.
select borrower_borrowername from tbl_borrower tb
left join tbl_book_loans tbl
on tb.borrower_cardno = tbl.book_loans_CardNo
where book_loans_DateOut is null;

-- For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, and the borrower's address. 
select tbk.book_Title, tb.borrower_BorrowerName,tb.borrower_BorrowerAddress from tbl_library_branch tlb
left join tbl_book_loans tbl on tlb.library_branch_branchid = tbl.book_loans_BranchID
left join tbl_borrower tb on tbl.book_loans_cardno = tb.borrower_CardNo
left join tbl_book tbk on tbk.book_bookid = tbl.book_loans_BookID
where tlb.library_branch_BranchName = "sharpstown" and tbl.book_loans_DueDate = "2018-03-02";

-- For each library branch, retrieve the branch name and the total number of books loaned out from that branch.
select library_branch_BranchName, count(book_loans_LoansID) from tbl_library_branch tlb
left join tbl_book_loans tbl on tlb.library_branch_branchid = tbl.book_loans_BranchID
group by library_branch_BranchName;

-- Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.
select borrower_BorrowerName,borrower_BorrowerAddress, count(book_loans_DateOut) as no_of_books_checkedout from tbl_book_loans tbl
left join tbl_borrower tb on tbl.book_loans_cardno = tb.borrower_CardNo
group by book_loans_CardNo
having no_of_books_checkedout > 5;

-- For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch whose name is "Central".
select book_Title, count(book_copies_No_Of_Copies) as No_Of_Copies from tbl_book_authors tba
left join tbl_book tb on tba.book_authors_BookID = tb.book_BookID
left join tbl_book_copies tbc on tb.book_BookID = tbc.book_copies_BookID
left join tbl_library_branch tlb on tlb.library_branch_BranchID = tbc.book_copies_BranchID
where book_authors_AuthorName = "Stephen King" and library_branch_BranchName = "central"
group by book_Title;